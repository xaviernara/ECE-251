
public class UnderstandingIFProgramTest {
	public static void main(String args[]) {
		 UnderstandingIFProgram u = new UnderstandingIFProgram();
		 u.question();
		 }
		
}
