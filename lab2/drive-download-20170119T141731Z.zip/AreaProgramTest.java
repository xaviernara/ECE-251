package lab2;

public class AreaProgramTest {
	public static void main(String args[])
	
	{
		//this line calls the AreaProgram file and then sends it the info from the areaProgram into the function computeArea and computes it
			AreaProgram areaProgram = new AreaProgram (5);
		System.out.println("The area is " + areaProgram.computeArea ( ));
		
	}
}
