
public class MoneyProgram {

		float a = 10.00f;
		float b = 20.20f;
		float c = 3.01f;
		float d = 0.12f;
		float e = 67.78923f;
		public void display(){
		 System.out.printf("$%.2f \n", a);
		 System.out.printf("$%.2f \n", b);
		 System.out.printf("$%.2f \n", c);
		 System.out.printf("$%.2f \n", d);
		 System.out.printf("$%.2f \n", e);
		 
		
		}
}
